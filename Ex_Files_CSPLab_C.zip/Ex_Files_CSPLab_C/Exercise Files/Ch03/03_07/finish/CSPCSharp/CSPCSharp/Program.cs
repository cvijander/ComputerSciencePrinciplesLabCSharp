﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSPCSharp
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] myArray = new string[] { "Doug", "Mike", "Janet", "Matt" };
            Console.WriteLine(myArray[0]);

            //Console.WriteLine(myArray[4]);
        }
    }
}
