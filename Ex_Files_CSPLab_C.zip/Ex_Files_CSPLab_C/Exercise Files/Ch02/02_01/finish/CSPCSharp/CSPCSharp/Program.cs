﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSPCSharp
{
    class Program
    {
        static void Main(string[] args)
        {
            // Define a variable with a value
            float myNumber = 25.50f;

            // Send the value of the variable to the console
            Console.WriteLine(myNumber);
        }
    }
}
