﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSPCSharp
{
    class Program
    {
        static void Main(string[] args)
        {
            int myValue = 5;

            int anotherValue = new Int16();
            anotherValue = 5;
        }
    }
}
